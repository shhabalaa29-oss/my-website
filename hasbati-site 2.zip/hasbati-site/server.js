const express = require("express");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "ChangeMe123!";

let rates = {
  USD: 1, EUR: 0.85, JOD: 0.709, SAR: 3.75,
  AED: 3.672, GBP: 0.74, KWD: 0.306, TRY: 41
};

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-session-secret",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:false}
}));

app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next){
  if(req.session.user) return next();
  res.status(401).json({error:"غير مصرح"});
}

app.post("/api/login",(req,res)=>{
  if(req.body.username===ADMIN_USER && req.body.password===ADMIN_PASS){
    req.session.user=ADMIN_USER;
    return res.json({ok:true});
  }
  res.status(401).json({error:"اسم المستخدم أو كلمة السر غير صحيحة"});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/rates",(req,res)=>res.json(rates));
app.get("/api/me",(req,res)=>res.json({loggedIn:!!req.session.user}));

app.put("/api/rates",auth,(req,res)=>{
  const next={};
  for(const [code,value] of Object.entries(req.body)){
    const n=Number(value);
    if(!/^[A-Z]{3}$/.test(code) || !Number.isFinite(n) || n<=0) return res.status(400).json({error:"بيانات غير صحيحة"});
    next[code]=n;
  }
  rates=next;
  res.json({ok:true,rates});
});

app.listen(PORT,()=>console.log(`Hasbati running on port ${PORT}`));
